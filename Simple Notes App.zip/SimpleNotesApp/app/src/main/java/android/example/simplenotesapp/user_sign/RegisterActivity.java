package android.example.simplenotesapp.user_sign;

import androidx.appcompat.app.AppCompatActivity;

import android.example.simplenotesapp.R;
import android.os.Bundle;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
}
