package android.example.simplenotesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;

import static android.util.Log.i;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseAuth = FirebaseAuth.getInstance();


        updateUI();



    }
    public void updateUI(){
        if(firebaseAuth.getCurrentUser()!= null){
             Log.i("MainActivity", "firebaseAuth!=null");
        }
        else{
            Intent intent= new Intent(MainActivity.this, StartActivity.class);
            startActivity(intent);
            finish();
            Log.i("MainActivity", "firebaseAuth==null");
        }
    }
}
